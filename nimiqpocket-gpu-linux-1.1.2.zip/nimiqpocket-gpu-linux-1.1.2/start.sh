#!/bin/bash

./nimiqpocket
